# Feedback

[Go back to Documentation home page ](../README.md)

We are continuously making improvements to this Ansible collection and would love to hear from you!

* Please send your suggestions and feedback to: [cohesity-api-sdks@cohesity.com](mailto:cohesity-api-sdks@cohesity.com)

* You can also report issues or request enhancements on GitHub: [Create a new issue](https://github.com/cohesity/ansible-collection/issues/new)
